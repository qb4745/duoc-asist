export interface IUserLogin {
    username: string;
    password: string;
    email: string;
}
